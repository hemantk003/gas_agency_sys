package controllers;

public class NewConnectionRequests extends CRUD {

}
