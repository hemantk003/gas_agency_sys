package controllers;

public class States extends CRUD {

}
