package controllers;

public class Citys extends CRUD{

}
