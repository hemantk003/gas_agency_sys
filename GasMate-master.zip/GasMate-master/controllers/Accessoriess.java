package controllers;

public class Accessoriess extends CRUD {

}
