package controllers;

public class GasCylinders extends CRUD {

}
