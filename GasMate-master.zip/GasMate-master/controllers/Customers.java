package controllers;

public class Customers extends CRUD{

}
