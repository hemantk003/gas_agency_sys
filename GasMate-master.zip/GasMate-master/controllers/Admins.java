package controllers;

public class Admins extends CRUD {

}
