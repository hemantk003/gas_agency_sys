package controllers;

public class Dealers extends CRUD {

}
