package controllers;

public class ChangeLocations extends CRUD{

}
