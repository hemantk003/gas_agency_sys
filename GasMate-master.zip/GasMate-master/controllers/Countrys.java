package controllers;

public class Countrys extends CRUD{

}
