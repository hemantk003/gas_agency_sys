/* This java class in not a Controller . It helps to create OrderId,Application number ie,Sequence Number for those */

package controllers;


public class SequenceNumberGenerator {

}
