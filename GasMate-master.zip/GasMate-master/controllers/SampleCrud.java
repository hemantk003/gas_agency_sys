package controllers;
import models.*;

@CRUD.For(Account.class)
public class SampleCrud extends CRUD{

}
