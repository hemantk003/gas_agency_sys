package controllers;

public class Accounts extends CRUD{

}
