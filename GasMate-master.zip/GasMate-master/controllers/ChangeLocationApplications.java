package controllers;

public class ChangeLocationApplications extends CRUD {

}
