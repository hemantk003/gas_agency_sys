package controllers;

public class DealerCommercialOrders extends CRUD {

}
