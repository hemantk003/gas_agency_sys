GasMate
========

This webapp uses play framework and follows the mvc architecture

http://playframework.com

It was done when I was in college 2nd Year for the IBM's The Great Mind Challenge - My first venture into HTML/CSS/JavaScript.

