package models;

public enum Title {
	Mr, Ms
}
