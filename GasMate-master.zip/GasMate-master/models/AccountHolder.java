package models;

public enum AccountHolder {
	ADMIN,CUSTOMER,DEALER
}
