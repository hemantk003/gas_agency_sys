/*package models;
import java.util.*;

import javax.persistence.*;

import play.db.jpa.*;


@Entity
@Table(name="endservicecertificate")

public class EndService  extends Model{
	
	/**
	 * @param timestamp
	 * @param applicationId
	 * @param consumerNumber
	 * @param cerificatenumber
	 */
	/*public EndService(Date timestamp, Long applicationId,
			Customer consumerNumber, Long cerificatenumber) {
		super();
		this.timestamp = timestamp;
		this.applicationId = applicationId;
		this.consumerNumber = consumerNumber;
		this.cerificatenumber = cerificatenumber;
	}

	public EndService() {
		// TODO Auto-generated constructor stub
	}

	//TimeStamp;
	public Date timestamp;
	
	//application number;
	@ManyToOne
	public Long applicationId;
	
	// Customer Number;
	@ManyToOne
	public Customer consumerNumber;
	
	//Certificate number;
	public Long cerificatenumber;

	public boolean isApproved;

}*/
