package models;

import java.io.*;

public enum  GasCylinderType {

	DOMESTIC,COMMERCIAL
}
