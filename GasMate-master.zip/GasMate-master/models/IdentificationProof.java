package models;

public enum IdentificationProof {
	RATIONCARD, ELECTRICITYBILL, TELEPHONEBILL, PASSPORT, EMPLOYERCERTIFICATE,POSSESSIONLETTER,HOUSEREGISTRATIONPAPERS, LICPOLICY,VOTERIDENTITYCARD, PANCARD, DRIVINGLICENSE, BANKACCOUNT, WATERBILL, UNIQUEID

}

/*
if(id == "Ration Card"){
	
	n.id = IdentificationProoof.RATIONCARD;
}
else if (id = "Electricity Bill"){
	n.id =IdentificationProoof.ELECTRICITYBILL
}
else if (id = "Telephone Bill" )
{
	n.id = IdentificationProoof.TELEPHONEBILL
}
else if (id = "Passport" )
{
	n.id = IdentificationProoof.PASSPORT
}
else if (id = "Employer Certificate" )
{
	n.id = IdentificationProoof.EMPLOYERCERTIFICATE
}
else if (id = "Possession Letter" )
{
	n.id = IdentificationProoof.POSSESSIONLETTER
}
else if (id = "House Registration Papers" )
{
	n.id = IdentificationProoof.HOUSEREGISTRATIONPAPERS
}
else if (id = "Lic Policy" )
{
	n.id = IdentificationProoof.LICPOLICY
}
else if (id = "Voter Identity Card" )
{
	n.id = IdentificationProoof.VOTERIDENTITYCARD
}
else if (id = "Pan Card" )
{
	n.id = IdentificationProoof.PANCARD
}
else if (id = "Driving License" )
{
	n.id = IdentificationProoof.DRIVINGLICENSE
}
else if (id = "Bank Account" )
{
	n.id = IdentificationProoof.BANKACCOUNT
}
else if (id = "Water Bill" )
{
	n.id = IdentificationProoof.WATERBILL
}
else if (id = "Unique Id") {
	n.id =IdentificationProoof.UNIQUEID
}




	
*/

