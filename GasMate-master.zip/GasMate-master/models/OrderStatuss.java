package models;

public enum OrderStatuss {
		ORDERED,DELIVERED,WAITING,CANCELLED
}
